
const express = require('express');
const carService = require('./services/carService');

const app = express();

const port = 3500;

app.get('/', (req, res) => {
    res.send('Assessment service app');
});

app.get('/cars', (req, res) => {
    let cars = carService.getCars();
    res.json(cars);
});

app.listen(port, () => console.log(`Assessment service app listening on port ${port}!`))