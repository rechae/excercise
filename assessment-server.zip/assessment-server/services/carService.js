
const extend = require('node.extend');

module.exports = extend(exports, {
  getCars: function getCars() {
    const carList = [{name: "BMW 1 Series", yearModel: 2019}, {name: "BMW 2 Series", yearModel: 2019}, {name: "BMW 3 Series", yearModel: 2017 },{name: "BMW X1", yearModel: 2018}, {name: "BMW X2", yearModel: 2020}];
    return carList;
  }
});
