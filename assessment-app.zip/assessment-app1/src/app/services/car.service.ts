﻿﻿import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { ConfigService } from './config.service';

@Injectable()
export class CarService {
  constructor(private http: HttpClient, private configService: ConfigService) {}

  getCars(): Observable<any> {
   // const REST_URL = `${this.baseUrl()}`;
    return this.http.get('cars');
  }

}
