import { Component, OnInit } from '@angular/core';
import { CarService } from './services/car.service';

@Component({
  selector: 'assesment-app',
  templateUrl: './car.component.html',
  providers: [CarService],
  styleUrls: ['./car.component.css']
})
export class CarComponent implements OnInit {
  cars = [];
  constructor(private carService: CarService) {}

  ngOnInit() {
    this.getCars();
  }

  getCars(): void {
    this.carService.getCars()
      .subscribe(cars => (this.cars = cars));
  }
}
